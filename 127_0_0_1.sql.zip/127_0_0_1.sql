-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 24, 2021 at 11:18 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ff`
--
CREATE DATABASE IF NOT EXISTS `ff` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ff`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `CustID` int(5) NOT NULL AUTO_INCREMENT,
  `CustName` varchar(20) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `PhoneNum` varchar(40) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `OrderID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CustID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustID`, `CustName`, `Password`, `PhoneNum`, `Address`, `Email`, `OrderID`) VALUES
(1, 'Emma', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2323232', 'g32dfg32dfg32dfg23', 'sdsd@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `ProductID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Price` decimal(5,2) NOT NULL,
  `Quantity` int(3) NOT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `Name`, `Image`, `Price`, `Quantity`) VALUES
(1, 'Watermelon', NULL, '3.00', 20),
(4, 'Grape', NULL, '1.90', 0),
(5, 'Orange', NULL, '2.50', 30);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
